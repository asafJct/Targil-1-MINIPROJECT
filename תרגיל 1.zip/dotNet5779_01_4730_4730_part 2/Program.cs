﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5779_01_4730_4730_part_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] intArray = new int[5][];

            for (int i = 0; i < 5; i++)
            {
                intArray[i] = new int[5];
                for (int j = 0; j < 5; j++)
                    intArray[i][j] = int.Parse(Console.ReadLine()) ;
            }

            int sum1 = 0, sum2 = 0, sum3 = 0;

            for (int i  = 0; i  <5; i ++)
            {
                sum1 += intArray[1][i];
            }

            for (int i = 0; i < 5; i++)
            {
                sum2 += intArray[i][1];
            }

            for (int i = 0; i < 5; i++)
            {
                sum3 += intArray[i][i];
            }

            if(sum1==sum2 && sum2==sum3)
            {
                Console.WriteLine("yes");
            }

            else
                Console.WriteLine("no");
            {

            }
            {

                }
            }
        }
    }
}
