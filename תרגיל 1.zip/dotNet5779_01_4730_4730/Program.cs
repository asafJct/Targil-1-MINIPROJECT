﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5779_01_4730_4730
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[100];
            Random r = new Random();

            for (int i = 0; i < 100; i++)
            {
                intArray[i] = r.Next(0, 1000);
            }
            #region
            int B=int.Parse(Console.ReadLine());
            int place=0;
            bool flag=false;

            do
            {
                if (B == intArray[place])
                    flag = true;
                place++;
            }

            while (!flag);
            if (flag)
            Console.WriteLine("The number found in Array");
            else
                Console.WriteLine("The number didn't find in Array");
            #endregion

//part 1.2 
            //Declare variables and read from user.
            int n1 = int.Parse(Console.ReadLine());
            char tav= char.Parse(Console.ReadLine());
            int n2 = int.Parse(Console.ReadLine());
            char tav2 = char.Parse(Console.ReadLine());
            int n3 = int.Parse(Console.ReadLine());
            int max, low;
            if (n2 < n3) { max = n3; low = n2; }
                
            else
            { max = n2; low = n3; }
            int count=0;
            for(int i=0; i<100; i++)
            {
                if(intArray[i]<max && intArray[i] > low)
                {
                    count++;
                }
            }
            
            if (n1==count)
                Console.WriteLine("Your guess was able");
            else
                Console.WriteLine("Your guess wasn't able");



        }
    }
}
